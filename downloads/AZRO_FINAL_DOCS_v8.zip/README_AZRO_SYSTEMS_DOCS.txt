AZRO Systems — Documentation Pack (v8 + additions)

Included:
- v8 PDFs and templates
- AZRO Treasury Standard v1 (PDF)
- Sample Monthly BTC Treasury Report (PDF)
- Sample Board Packet (PDF)

Disclaimer: informational only; not legal, tax, or financial advice.
