AZRO FINAL DOCUMENTATION PACK (PRINT FINAL v12)

This folder contains customer- and board-ready PDFs plus the supporting calculator templates.

PDFs
- AZRO_Customer_Packet_PRINT_FINAL_v12_v1.0.12.pdf
  Full customer-facing packet (intro + one-pager + performance addendum + policy memo + concerns + pitch kit).

- AZRO_One_Page_Pitch_Customer_PRINT_FINAL_v12_v1.0.12.pdf
  Single-page overview.

- AZRO_Board_Packet_PRINT_FINAL_v12_v1.0.12.pdf
  Board decision packet (board intro + performance addendum + policy memo + concerns).

- AZRO_Performance_Addendum_BTC_Standard_PRINT_FINAL_v12_v1.0.12.pdf
  Historical example + methodology (illustrative, not a forecast).

- AZRO_Bitcoin_Treasury_Policy_Memo_Template_PRINT_FINAL_v12_v1.0.12.pdf
  Fill-in-the-blank policy memo + guardrails + reporting checklist.

- AZRO_Bitcoin_Concerns_PRINT_FINAL_v12_v1.0.12.pdf
  Common Bitcoin objections with concise answers.

- AZRO_Pitch_Kit_Scripts_FAQ_PRINT_FINAL_v12_v1.0.12.pdf
  Talk tracks, objection handles, and FAQ.

Spreadsheets (templates)
- AZRO_BTC_Accretion_Compounding_Calculator_FINAL_v9_v1.0.12.xlsx
- AZRO_Long_Range_Scenario_Calculator_FINAL_v9_v1.0.12.xlsx
- AZRO_Monthly_BTC_Treasury_Report_Template_FINAL_v9_v1.0.12.xlsx
- AZRO_Performance_Addendum_Retest_Results_v11_v1.0.12.xlsx

Notes
- Some spreadsheets retain their original version numbers; the PDFs in this pack are the v12 print-final customer documents.
- These materials are informational and operational. They are not financial, legal, or tax advice.
